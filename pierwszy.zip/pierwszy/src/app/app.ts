import { Component, signal } from '@angular/core';
import {Osoba, Plec} from './interfejs';
import { FormsModule} from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  imports: [FormsModule, CommonModule],
  selector: 'app-root',
  styleUrl: './app.css',
  templateUrl: './app.html',
})
export class App {
  klasa: string="4TPI";
  zdjecie: string="technic.jpg";

  osoba: Osoba = {
    imie: "Marek",
    nazwisko: "Koewal",
    zdjecieOsoby: "",
    plec: Plec.nieokreslona
  }

  czyZdjecie: boolean = true;

  pokazuj(){
    this.czyZdjecie = !this.czyZdjecie;
  }

  plecZdjecie():string{
    if(this.osoba.plec == Plec.kobieta){
      return "kobieta.jpg"
    }
    else if(this.osoba.plec == Plec.mezczyzna){
      return "mezczyzna.jpg"
    }
    else{
      return "technic.jpg"
    }
  }
}
