export interface Osoba{
    imie: string,
    nazwisko:string,
    zdjecieOsoby:string,
    plec:Plec
}

export enum Plec{
    mezczyzna,
    kobieta,
    nieokreslona
}