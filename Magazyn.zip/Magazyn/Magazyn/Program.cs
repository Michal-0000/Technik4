﻿namespace Magazyn
{
    public static class Program
    {
        public static void Main(string[] args)
        {

        }



    }

    public class Produkt
    {
        public string nazwa;
        public float cena_netto;
        public int ilosc;

        public Produkt(string nazwa, float cena_netto, int ilosc)
        {
            this.nazwa = nazwa;
            this.cena_netto = cena_netto;
            this.ilosc = ilosc;
        }

        public float oblicz_wartosc_brutto(float vat = 23f)
        {
            return cena_netto * (100f + vat) / 100f;
        }

        public float oblicz_wartosc_magazynu_brutto()
        {
            return oblicz_wartosc_brutto() * ilosc;
        }

        public void wyswietl_opis()
        {
            Console.WriteLine(
                $"-------------------------------------\n" +
                $"Produkt: {nazwa}\n" +
                $"Ilość na stanie: {ilosc} szt.\n" +
                $"Cena netto: {cena_netto} PLN | Cena brutto: {oblicz_wartosc_brutto()} PLN\n" +
                $"Łączna wartość w magazynie (brutto): {oblicz_wartosc_magazynu_brutto} PLN\n" + // FORMATOWANI 
                "--------------------------------------"
                );
        }
    }
}